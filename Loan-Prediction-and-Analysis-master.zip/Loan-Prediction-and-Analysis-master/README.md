# Loan-Prediction-and-Analysis
Univariate Analysis of Loan Data of customer.
This Model Predict that a customer will repay the loan or not.
New Folder(k2) contains all the data in excel sheet.
